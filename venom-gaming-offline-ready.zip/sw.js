/* VENOM GAMING offline app cache */
const CACHE_NAME = 'venom-gaming-v1';
const CORE_FILES = [
  './',
  './index.html',
  './index-legacy.html',
  './design.html',
  './echo.html',
  './horror.html',
  './horror-1.html',
  './manifest.webmanifest',
  './icon-192.png',
  './icon-512.png',
  './file_000000002460820a9dacd0b234987f24.png',
  './file_000000005138820aa8792ad72d9db0fb.png',
  './file_000000005614820a8e76db7e00403475.png',
  './file_000000005e5c820a9b0a40b58044b559.png',
  './file_000000008b74820ab6f97f672f3dbb3d.png',
  './monster.glb'
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(CORE_FILES))
      .then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);

  // Cache Three.js modules from jsDelivr after their first successful online load.
  if (url.origin !== self.location.origin) {
    if (url.hostname === 'cdn.jsdelivr.net') {
      event.respondWith((async () => {
        const cache = await caches.open(CACHE_NAME);
        const saved = await cache.match(request);
        if (saved) return saved;
        try {
          const response = await fetch(request);
          if (response && (response.ok || response.type === 'opaque')) {
            try { await cache.put(request, response.clone()); } catch (_) {}
          }
          return response;
        } catch (_) {
          return saved || Response.error();
        }
      })());
    }
    return;
  }

  if (request.mode === 'navigate') {
    event.respondWith((async () => {
      const cache = await caches.open(CACHE_NAME);
      try {
        const response = await fetch(request);
        if (response && response.ok) cache.put(request, response.clone()).catch(() => {});
        return response;
      } catch (_) {
        return (await cache.match(request)) || (await cache.match('./index.html')) || Response.error();
      }
    })());
    return;
  }

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const saved = await cache.match(request);
    if (saved) {
      fetch(request).then(response => {
        if (response && response.ok) cache.put(request, response.clone());
      }).catch(() => {});
      return saved;
    }
    try {
      const response = await fetch(request);
      if (response && response.ok) cache.put(request, response.clone()).catch(() => {});
      return response;
    } catch (_) {
      return Response.error();
    }
  })());
});
